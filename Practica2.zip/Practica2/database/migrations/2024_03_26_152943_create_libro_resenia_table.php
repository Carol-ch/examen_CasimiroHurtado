<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLibroReseniaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('libro_resenia', function (Blueprint $table) {
            $table->id();
            $table->integer('libro_id');
            $table->integer('resenia_id');
            // Agregar otras columnas si es necesario

            // Definir las claves foráneas
            $table->foreign('libro_id')->references('id')->on('libros')->onDelete('cascade');
            $table->foreign('resenia_id')->references('id')->on('resenias')->onDelete('cascade');

            // Definir una clave única para evitar duplicados
            $table->unique(['libro_id', 'resenia_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('libro_resenia');
    }
}

