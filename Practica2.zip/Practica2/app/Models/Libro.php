<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Libro extends Model
{
    protected $fillable = ['nombre', 'email'];

    // Definir relaciones
    public function reservas()
    {
        return $this->hasMany(LibroReservado::class);
    }

    public function reseñas()
    {
        return $this->hasMany(LibroReservadoResenia::class);
    }
    use HasFactory;
}
