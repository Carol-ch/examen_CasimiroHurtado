<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Libro extends Controller
{
    //
}
