<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Resenia extends Controller
{
    //
}
