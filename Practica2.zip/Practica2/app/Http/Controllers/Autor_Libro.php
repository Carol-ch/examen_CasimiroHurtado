<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Autor_Libro extends Controller
{
    //
}
