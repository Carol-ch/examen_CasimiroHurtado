<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Categoria_Libro extends Controller
{
    //
}
