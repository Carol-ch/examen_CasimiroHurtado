<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Usuario_Libro_Resenia extends Controller
{
    //
}
